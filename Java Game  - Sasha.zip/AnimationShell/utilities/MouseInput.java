
public class MouseInput {
	
	protected static int screenX = 0;
	protected static int screenY = 0;
	
	protected static double logicalX = 0;
	protected static double logicalY = 0;

	protected static boolean leftButtonDown = false;
	protected static boolean rightButtonDown = false;
	
}
